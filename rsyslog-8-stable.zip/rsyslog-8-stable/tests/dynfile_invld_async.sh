#!/bin/bash
echo "\$OMFileAsyncWriting on" > rsyslog.action.1.include
. $srcdir/dynfile_cachemiss.sh
