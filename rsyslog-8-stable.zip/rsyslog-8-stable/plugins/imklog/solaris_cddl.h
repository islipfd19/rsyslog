void *sun_sys_poll();
int sun_openklog(char *name, int mode);
