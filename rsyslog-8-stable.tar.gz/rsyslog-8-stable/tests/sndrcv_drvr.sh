#!/bin/bash
. $srcdir/sndrcv_drvr_noexit.sh $1 $2
