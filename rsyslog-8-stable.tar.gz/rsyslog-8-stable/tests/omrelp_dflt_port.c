#include "config.h"
#include <stdio.h>

int
main(int __attribute__((unused)) argc, char * __attribute__((unused)) argv[])
{
	printf("%s", RELP_DFLT_PT);
	return 0;
}
