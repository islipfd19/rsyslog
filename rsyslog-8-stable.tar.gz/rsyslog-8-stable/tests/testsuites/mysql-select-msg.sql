use Syslog;
select substring(Message,9,8) from SystemEvents;
